export const paymentAddress = "0x4e37ADeEDc0480b3f3687Dc50FAa58504d17C643"
export const UsdApproveAddress = "0x55d398326f99059fF775485246999027B3197955"
export const BusdApproveAddress = "0xe9e7CEA3DedcA5984780Bafc599bD69ADd087D56"

